package secondQ;

public interface ShippingStrategy {
    void ship();
    int getCost();
}
