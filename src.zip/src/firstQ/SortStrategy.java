package firstQ;

public interface SortStrategy {
    void sort(int [] array);
}
