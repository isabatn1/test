package secondQ;

public interface PackagingStrategy {
    void pack();
    int getCost();
}
