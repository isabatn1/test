package firstQ;

public class QuickSort implements SortStrategy {


    @Override
    public void sort(int[] array) {
        System.out.println("QuickSort");
    }
}
