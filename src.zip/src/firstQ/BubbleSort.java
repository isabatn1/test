package firstQ;

public class BubbleSort implements SortStrategy {
    @Override
    public void sort(int[] array) {
        System.out.println("BubbleSort");

    }



}
